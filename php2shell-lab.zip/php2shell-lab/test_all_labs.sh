#!/usr/bin/env bash
# Test the exploit against all lab containers and print a summary table.
# Authorized testing only.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PHP2SHELL="$SCRIPT_DIR/php2shell"

if [ ! -d "$PHP2SHELL" ]; then
  echo "[-] php2shell not found — run ./setup.sh first"
  exit 1
fi

cd "$PHP2SHELL"

echo "[*] Running dispatcher against all labs..."
python3 tools/php2shell_labs.py test
