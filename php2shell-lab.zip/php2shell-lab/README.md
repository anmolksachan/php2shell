# PHP2Shell Lab — CVE-2026-109618 / CVE-2026-109619

Pre-auth RCE research toolkit for the `session.upload_progress` heap exploitation
chain in PHP's Apache `mod_php`.

> **Authorized testing only.** Use exclusively against systems you own or have
> explicit written permission to test.

---

## Quick Start

```bash
# 1. Setup: clone repo, bootstrap upstream exploit, start Docker labs
chmod +x *.sh
./setup.sh

# 2. Run the exploit against PHP 8.5.11 (verified RCE)
./run_exploit.sh

# 3. Run a custom command
./run_exploit.sh http://127.0.0.1:8106/index.php p2s-lab-8511 "id; uname -a"

# 4. Interactive REPL (one exploit chain per command)
./run_interactive.sh

# 5. Test all labs at once
./test_all_labs.sh

# 6. Tear down all containers when done
./cleanup.sh
```

---

## Lab Containers

| Port | PHP Build | Container | RCE |
|------|-----------|-----------|-----|
| :8100 | 7.4.33 | p2s-lab-7433 | no |
| :8101 | 8.0.30 | p2s-lab-8030 | no |
| :8102 | 8.1.34 | p2s-lab-8134 | no |
| :8103 | 8.2.34 | p2s-lab-8234 | no |
| :8104 | 8.3.35 | p2s-lab-8335 | no |
| :8105 | 8.4.26 | p2s-lab-8426 | **yes** |
| :8106 | 8.5.11 | p2s-lab-8511 | **yes** |

All containers: Apache prefork `mod_php`, 1 worker, `memory_limit=8M`,
`display_errors=On`, `session.upload_progress=On`, bound to `127.0.0.1` only.

---

## Script Reference

| Script | What it does |
|--------|-------------|
| `setup.sh` | Clone repo, bootstrap upstream, start all labs |
| `run_exploit.sh [url] [container] [cmd]` | Run exploit with optional target/command override |
| `run_interactive.sh [url] [container]` | Interactive REPL — one chain per command |
| `test_all_labs.sh` | Run dispatcher against all 7 labs |
| `cleanup.sh` | Stop and remove all containers |

---

## How the Chain Works

**Stage 1 — Heap Leak**
A multipart POST with ~841 fields drives `session.upload_progress` into an OOM
bailout after the session state is allocated. The stale `PS(id)` pointer left on
the heap leaks the **Zend MM chunk base** via the OOM error message in the response.

**Stage 2 — libphp Leak**
The same primitive is reshaped to leak a pointer into `libphp.so`, revealing its
**load base address** and defeating library ASLR.

**Stage 3 — RCE**
A forged HashTable and fake `zend_string` are placed at the stale session struct.
When `zval_ptr_dtor` runs the forged destructor, it jumps to `zif_system` at its
known address and executes the staged command as `www-data`.

---

## Patch & Mitigations

- **Patch:** Upgrade to PHP 8.4.27 or PHP 8.5.12
- **Disable:** `session.upload_progress.enabled = Off` in `php.ini` (removes the attack surface entirely)
- **Detect:** Watch for large multipart POSTs, repeated 500 errors, `zend_mm_heap corrupted` in Apache logs

---

## References

- https://github.com/devploit/php2shell
- https://github.com/9bie/php2shell-bypass-aslr-exp
- https://www.wiz.io/blog/php2shell-php-rce
- https://www.php.net/security/
