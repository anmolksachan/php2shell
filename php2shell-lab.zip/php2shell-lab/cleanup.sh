#!/usr/bin/env bash
# Stop and remove all php2shell lab containers.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PHP2SHELL="$SCRIPT_DIR/php2shell"

if [ ! -d "$PHP2SHELL" ]; then
  echo "[-] php2shell not found — nothing to clean up"
  exit 0
fi

cd "$PHP2SHELL"

echo "[*] Stopping lab containers..."
python3 tools/php2shell_labs.py down

echo "[+] All lab containers stopped."
